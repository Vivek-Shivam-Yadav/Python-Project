##cake question

print("Cake Question")
def piece1(cake_angle,N):
    if (cake_angle %N == 0):  ##cake will be cut into pieces of equal size if the condition is true
        print("Yes,the cake will cut in",N,"equal pieces of size",cake_angle//N)
    else:
        print("No,the cake will not cut in",N,"equal pieces")
def piece2(cake_angle,N):
    if N>cake_angle:   ##if N is greater than cake_angle,the cake cannot be cut into any pieces
        print("No,the cake cannot be cut into",N,"pieces of any size")
    else:
        print("Yes,the cake will cut into",N,"pieces of any size")
def piece3(cake_angle,N):
    n=1   ##start subtracting the cake in order to ensure that no two pieces are equal
    for i in range(N):
        cake_angle-=n
        n+=1
        if (cake_angle < 0):
            print("NO,the cake will not cut into",N,"pieces such that no two of them are equal")
            break
    else:
        print("Yes,the cake will cut into",N,"pieces such that no two of them are equal")
cake_angle=int(input("Enter the angle of cake: "))
N=int(input("Enter the value N: "))
piece1(cake_angle,N)
piece2(cake_angle,N)
piece3(cake_angle,N)

